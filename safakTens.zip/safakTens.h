#ifndef safakTens_H
#define safakTens_H

#include <Arduino.h>

class tens {
  public:  
    tens();
    void tensNorm(int pulseWidth, int hertz);
	void tensMod(int pulseWidth, int hertz);
    void tensBurst();
  };

  #endif
