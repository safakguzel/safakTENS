#include "safakTens.h"

int led=13;
int cikis=12;
int gecikme;
int j=0, k=0;

tens::tens()
{

  pinMode(led, OUTPUT);
  pinMode(cikis, OUTPUT);
  
}

void tens :: tensNorm(int pulseWidth, int hertz)
{
	while (!Serial.available()==1)
	{
		gecikme = (1000/hertz)-(pulseWidth/1000);
		digitalWrite(led, HIGH);
		digitalWrite(cikis, LOW);
		delayMicroseconds(pulseWidth);
		digitalWrite(led, LOW);
		digitalWrite(cikis, HIGH);
		delay(gecikme);
    }
}

void tens :: tensMod(int pulseWidth, int hertz)
{
	while (!Serial.available()==1)
	{
		k=0;
		for(k=0; k<100; k++)
			{
				gecikme = (1000/hertz)-(pulseWidth/1000); 
				digitalWrite(led, HIGH);
				digitalWrite(cikis, LOW);
				delayMicroseconds(pulseWidth);
				digitalWrite(led, LOW);
				digitalWrite(cikis, HIGH);
				delay(gecikme);
				pulseWidth+=1;
					if(!Serial.available()==0)
						break;
			}
	
		for(k=100; k>0; k--)
			{
				gecikme = (1000/hertz)-(pulseWidth/1000); 
				digitalWrite(led, HIGH);
				digitalWrite(cikis, LOW);
				delayMicroseconds(pulseWidth);
				digitalWrite(led, LOW);
				digitalWrite(cikis, HIGH);
				delay(gecikme);
				pulseWidth-=1;
					if(!Serial.available()==0)
						break;
			}
	}
}

void tens :: tensBurst()
{
	while (!Serial.available()==1)
	{
		for (int i=0; i<50; i++)
			{
				digitalWrite(led, HIGH);
				digitalWrite(cikis, LOW);
				delayMicroseconds(200);
				digitalWrite(led, LOW);
				digitalWrite(cikis, HIGH);
				delay(9.8);
			}
		delay(500);
	}
}
